#!/usr/bin/env python3
"""Lightweight pre-delivery audit for scene-driven strategic investment deliverables.

Usage:
  python audit_deliverables.py --root /absolute/path/to/workdir \
      [--ppt-project /absolute/path/to/ppt_project] [--output audit.md]

The script is intentionally conservative. It identifies issues for human review;
it does not make investment, legal, market, or design judgments.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
import xml.etree.ElementTree as ET

FORBIDDEN_PHRASES = (
    "只研究",
    "条件性搜索",
    "自动取得",
    "自然取得",
    "用户提供",
    "内部信息",
)

ABBREVIATION_RE = re.compile(r"\b[A-Z][A-Z0-9]{1,9}(?:/[A-Z][A-Z0-9]{1,9})?\b")
TICKER_RE = re.compile(r"\b\d{4,6}\.(?:HK|SH|SZ|NYSE|NASDAQ)\b", re.IGNORECASE)


def shorten(text: str, limit: int = 100) -> str:
    text = " ".join(text.split())
    return text if len(text) <= limit else text[: limit - 1] + "…"


def locate(text: str, token: str) -> str:
    pos = text.find(token)
    if pos < 0:
        return ""
    start = max(0, pos - 42)
    end = min(len(text), pos + len(token) + 58)
    return shorten(text[start:end])


def audit_text_file(path: Path, findings: list[dict[str, str]]) -> None:
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return

    relative = str(path)
    for phrase in FORBIDDEN_PHRASES:
        if phrase in text:
            findings.append({
                "severity": "需复核",
                "file": relative,
                "check": "可能的工作黑话或错误权利暗示",
                "evidence": locate(text, phrase),
                "action": "改为直白业务语言；如涉及数据、接口、订单或验收，明确其须经授权、合同、测试或治理安排落实。",
            })

    for ticker in sorted(set(TICKER_RE.findall(text))):
        findings.append({
            "severity": "提示",
            "file": relative,
            "check": "可能的公司代码",
            "evidence": ticker,
            "action": "若正在制作可复用技能、模板或示例，删除可识别企业信息；若为当前项目交付，可保留并确认来源。",
        })

    abbreviations = sorted(set(ABBREVIATION_RE.findall(text)))
    unexplained = []
    for abbr in abbreviations:
        # A nearby opening parenthesis is a lightweight heuristic, not a guarantee.
        first = text.find(abbr)
        vicinity = text[max(0, first - 30): first + len(abbr) + 30]
        if "（" not in vicinity and "(" not in vicinity:
            unexplained.append(abbr)
    if unexplained:
        findings.append({
            "severity": "提示",
            "file": relative,
            "check": "可能未在首次出现处标注中文全称的缩写",
            "evidence": "、".join(unexplained[:12]),
            "action": "人工核对首次出现处，采用“中文全称（英文缩写）+业务解释”；品牌、法规编号和广为人知名称可排除。",
        })


def audit_ppt_project(project: Path, findings: list[dict[str, str]]) -> None:
    state_file = project / "slide_state.json"
    if state_file.exists():
        try:
            state = json.loads(state_file.read_text(encoding="utf-8"))
            slides = state.get("slides", [])
            edited = [slide for slide in slides if slide.get("state") == "edited"]
            if len(edited) != len(slides):
                findings.append({
                    "severity": "需修复",
                    "file": str(state_file),
                    "check": "PPT页面完成状态",
                    "evidence": f"已编辑 {len(edited)}/{len(slides)} 页",
                    "action": "完成所有待编辑页后重新呈现演示文稿。",
                })
        except Exception as exc:  # noqa: BLE001
            findings.append({
                "severity": "需修复",
                "file": str(state_file),
                "check": "PPT状态文件可读取性",
                "evidence": str(exc),
                "action": "修复状态文件或重新初始化项目。",
            })

    for xml_file in project.glob("*.xml"):
        try:
            root = ET.parse(xml_file).getroot()
        except Exception as exc:  # noqa: BLE001
            findings.append({
                "severity": "需修复",
                "file": str(xml_file),
                "check": "PPT XML可解析性",
                "evidence": str(exc),
                "action": "修复XML后重新呈现。",
            })
            continue

        seen: set[str] = set()
        for elem in root:
            if elem.tag == "background":
                continue
            item_id = elem.attrib.get("id", "")
            if not item_id or item_id in seen:
                findings.append({
                    "severity": "需修复",
                    "file": str(xml_file),
                    "check": "PPT元素ID",
                    "evidence": item_id or "缺失ID",
                    "action": "为每个内容元素设置语义明确且唯一的id。",
                })
            seen.add(item_id)
            try:
                x = float(elem.attrib.get("x", 0))
                y = float(elem.attrib.get("y", 0))
                width = float(elem.attrib.get("width", 0))
                height = float(elem.attrib.get("height", 0))
                if x < 0 or y < 0 or x + width > 1280 or y + height > 720:
                    findings.append({
                        "severity": "需修复",
                        "file": str(xml_file),
                        "check": "PPT元素边界",
                        "evidence": f"id={item_id}; x={x}, y={y}, w={width}, h={height}",
                        "action": "将元素调整至画布内，并在呈现后完成视觉检查。",
                    })
            except ValueError:
                findings.append({
                    "severity": "需修复",
                    "file": str(xml_file),
                    "check": "PPT元素坐标",
                    "evidence": f"id={item_id}",
                    "action": "使用合法数值坐标。",
                })


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, help="待审计交付目录的绝对路径")
    parser.add_argument("--ppt-project", help="可选：manus-pptx项目目录")
    parser.add_argument("--output", help="可选：审计Markdown输出路径")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    if not root.exists() or not root.is_dir():
        raise SystemExit(f"工作目录不存在：{root}")
    output = Path(args.output).resolve() if args.output else root / "strategic_investment_delivery_audit.md"

    findings: list[dict[str, str]] = []
    main_files = {
        "领导审阅版": list(root.glob("*领导*.*")),
        "详细支撑版": list(root.glob("*详细*.*")),
        "战略投资主表": list(root.glob("*.xlsx")),
        "导航文件": list(root.glob("*导航*.csv")) + list(root.glob("*导航*.md")),
    }
    for name, files in main_files.items():
        if not files:
            findings.append({
                "severity": "需复核",
                "file": str(root),
                "check": f"主交付文件：{name}",
                "evidence": "未按默认命名模式发现",
                "action": "确认用户是否明确缩减交付；否则补齐或在导航文件说明。",
            })

    for text_file in list(root.glob("*.md")) + list(root.glob("*.csv")):
        if text_file.resolve() != output:
            audit_text_file(text_file, findings)

    if args.ppt_project:
        project = Path(args.ppt_project).resolve()
        if not project.exists():
            findings.append({
                "severity": "需修复",
                "file": str(project),
                "check": "PPT项目路径",
                "evidence": "目录不存在",
                "action": "提供正确的演示项目目录。",
            })
        else:
            audit_ppt_project(project, findings)

    blockers = [item for item in findings if item["severity"] == "需修复"]
    lines = [
        "# 场景驱动战略投资研究｜交付初筛审计",
        "",
        f"**工作目录：** `{root}`  ",
        f"**结果：** 发现 {len(findings)} 项提示/问题，其中 {len(blockers)} 项需修复。  ",
        "> 本脚本只做结构、文本和基本PPT元素检查；事实、市场、法律适用、总拥有成本、商业模式与投资判断必须由人工完成深度复核。",
        "",
        "| 优先级 | 文件 | 检查项 | 证据 | 建议动作 |",
        "|---|---|---|---|---|",
    ]
    if findings:
        for item in findings:
            lines.append("| {severity} | `{file}` | {check} | {evidence} | {action} |".format(**item))
    else:
        lines.append("| 通过 | — | 自动初筛 | 未发现结构或措辞提示 | 仍需按技能质量清单完成事实、经济性、逻辑和视觉复核。 |")
    lines += ["", "## 人工复核结论", "- [ ] 已按`references/evidence-economics-and-quality.md`完成全部人工质量门槛。", "- [ ] 已确认技能/模板/示例不含上一项目的可识别信息。", "- [ ] 已在最后一次PPT呈现后更新导航与主Excel内的最终链接。", ""]
    output.write_text("\n".join(lines), encoding="utf-8")
    print(f"审计完成：{len(findings)} 项提示/问题，{len(blockers)} 项需修复；输出：{output}")
    return 1 if blockers else 0


if __name__ == "__main__":
    raise SystemExit(main())
