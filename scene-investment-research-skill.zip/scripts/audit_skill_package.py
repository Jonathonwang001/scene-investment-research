#!/usr/bin/env python3
"""Static audit for the scene-driven strategic investment research skill package.

This script checks that required workflow guardrails and resources exist. It does
not replace human review of factual accuracy, investment logic, or visual quality.

Usage:
  python audit_skill_package.py [--skill-dir /home/ubuntu/skills/scene-driven-strategic-investment-research]
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path

REQUIRED_FILES = (
    "SKILL.md",
    "references/research-framework.md",
    "references/evidence-economics-and-quality.md",
    "references/strategic-choice-and-portfolio.md",
    "references/early-stage-industrialization-and-sovereign-supply.md",
    "references/mbb-decision-deck.md",
    "references/reverse-quality-review.md",
    "templates/decision-workbook-and-deck-map.md",
    "templates/strategic-node-card.md",
    "templates/slide-content-outline.md",
    "scripts/audit_deliverables.py",
)

REQUIRED_CONCEPTS = {
    "企业真实能力边界": "以企业事实而非行业标签起步",
    "维持现状—采购—合作—自建—投资—并购": "资本动作反事实比较",
    "完整产业链": "从问题到上中下游及责任链的全链研究",
    "总拥有成本": "成本、工程、责任与切换边界",
    "价值池": "市场和商业模式从价值/付费/收费单元推导",
    "定义—对标—反证—结论": "关键命题的四步验证",
    "行动标题": "MBB式结论先行页面设计",
    "MECE": "问题树和分类的相互独立、共同穷尽",
    "主事实源": "跨文件版本与事实一致性",
    "零协同": "不把未签约协同或权利计入基准情景",
    "阶段适配型证据": "早期标的不使用成熟公司门槛机械筛选",
    "成本曲线": "技术产业化不以实验室或代际指标直接推导",
    "七项条件": "国产替代/供应安全作为条件性加分",
    "收费单元": "商业模式与价值捕获不能只看总市场",
    "去敏": "删除上一项目可识别信息",
    "停止条件": "明确投资/验证退出闸门",
}

SENSITIVE_PATTERNS = {
    "中国/香港证券代码": re.compile(r"\b\d{4,6}\.(?:HK|SH|SZ)\b", re.IGNORECASE),
    "绝对项目工作目录": re.compile(r"/home/ubuntu/(?!skills/)[^\s`]*", re.IGNORECASE),
}

# 静态审计只检查面向未来任务加载的自然语言资源。脚本、自身输出和开发记录
# 含有规则文字或路径，不应被当作待交付模板的敏感信息。
FORMAL_TEXT_DIRS = {"references", "templates"}
FORMAL_TEXT_FILES = {"SKILL.md"}


def get_all_text(skill_dir: Path) -> str:
    text_parts: list[str] = []
    for file_path in skill_dir.rglob("*"):
        if file_path.suffix.lower() not in {".md", ".txt", ".csv"}:
            continue
        relative = file_path.relative_to(skill_dir)
        if relative.name not in FORMAL_TEXT_FILES and not (relative.parts and relative.parts[0] in FORMAL_TEXT_DIRS):
            continue
        try:
            text_parts.append(file_path.read_text(encoding="utf-8"))
        except UnicodeDecodeError:
            pass
    return "\n".join(text_parts)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--skill-dir",
        default="/home/ubuntu/skills/scene-driven-strategic-investment-research",
        help="技能目录绝对路径",
    )
    args = parser.parse_args()
    skill_dir = Path(args.skill_dir).resolve()
    if not skill_dir.is_dir():
        raise SystemExit(f"技能目录不存在：{skill_dir}")

    failures: list[str] = []
    warnings: list[str] = []
    for relative in REQUIRED_FILES:
        if not (skill_dir / relative).is_file():
            failures.append(f"缺少必需资源：`{relative}`")

    all_text = get_all_text(skill_dir)
    for concept, reason in REQUIRED_CONCEPTS.items():
        if concept not in all_text:
            failures.append(f"缺少关键方法：{reason}（未找到“{concept}”）")

    for name, pattern in SENSITIVE_PATTERNS.items():
        matches = pattern.findall(all_text)
        if matches:
            failures.append(f"可能未去敏：发现{name}：{', '.join(sorted(set(matches))[:5])}")

    if "SST式" in all_text:
        warnings.append("发现具体技术示例命名“SST式”；建议使用通用的“完整产业链深钻结构”。")
    # “不得投资后自动取得……”属于必要的防错规则，不能与肯定式主张混淆。
    # 自动化脚本不判断自然语言肯定/否定语境，此项交由人工红队审查。

    lines = [
        "# 可复用技能｜严格静态审计结果",
        "",
        f"**技能目录：** `{skill_dir}`  ",
        f"**结论：** {'通过' if not failures else '未通过'}；发现 {len(failures)} 项需修复、{len(warnings)} 项提示。",
        "",
        "> 本审计验证技能包结构与关键方法是否已写入；不会替代对未来每个项目的事实、法律、市场、经济性、投资判断、可编辑性和视觉质量的人工作业。",
        "",
        "| 类型 | 审计发现 |",
        "|---|---|",
    ]
    if failures or warnings:
        for item in failures:
            lines.append(f"| 需修复 | {item} |")
        for item in warnings:
            lines.append(f"| 提示 | {item} |")
    else:
        lines.append("| 通过 | 所有必需资源、关键方法和基础去敏规则均已通过静态检查。 |")
    lines += [
        "",
        "## 人工复核确认",
        "- [ ] 已阅读`references/reverse-quality-review.md`，并完成反事实、红队、TCO、价值池、MBB和去敏的人工复核。",
        "- [ ] 已确认模板、示例、脚本和附件不会反向识别上一项目。",
        "- [ ] 已在真实任务中完成一次从企业事实卡到五份可编辑交付的端到端验证。",
        "",
    ]
    output = skill_dir / "skill_package_audit.md"
    output.write_text("\n".join(lines), encoding="utf-8")
    print(f"技能包审计：{len(failures)} 项需修复，{len(warnings)} 项提示；输出：{output}")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
